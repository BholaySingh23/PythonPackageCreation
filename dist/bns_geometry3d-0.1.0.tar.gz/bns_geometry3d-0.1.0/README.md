# geometry3d

A Python package to calculate the surface areas of 3D shapes.

## Installation
```bash
pip install bns_geometry3d
